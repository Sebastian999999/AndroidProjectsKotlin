package com.hammadirfan.smdproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.hammadirfan.smdproject.R

class visitHistory : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_visit_history)
    }
}