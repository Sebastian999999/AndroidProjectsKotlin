package com.HammadIrfan.i191994

import android.widget.Button
import androidx.lifecycle.Lifecycle
import androidx.test.core.app.ActivityScenario
import androidx.test.core.app.launchActivity
import org.junit.Before
import org.junit.Test


class Screen6Test{
private lateinit var scenario:ActivityScenario<Screen6>

@Before
fun setup(){
scenario = launchActivity()
scenario.moveToState(Lifecycle.State.CREATED)

}

    @Test
    fun testNavigation() {
        scenario.onActivity { activity ->
            activity.findViewById<Button>(R.id.backbutton).performClick()
        }

        scenario.onActivity { activity ->
            activity.findViewById<Button>(R.id.verifybutton).performClick()
        }
    }
}