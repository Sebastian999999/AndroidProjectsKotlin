package com.HammadIrfan.i191994

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Screen14 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen14)
    }
}