package com.HammadIrfan.i191994
import android.content.Intent
import android.os.Bundle
import android.text.SpannableString
import android.text.style.UnderlineSpan
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class Screen2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen2)

        val btnlgn = findViewById<Button>(R.id.loginbutton)
        val btnreg = findViewById<TextView>(R.id.text4)
        val btnfgt = findViewById<TextView>(R.id.forgotpassword)
        btnlgn.setOnClickListener{
            val intent = Intent(this, Screen7::class.java)
            startActivity(intent)
        }

        btnreg.setOnClickListener{
            val intent = Intent(this, Screen3::class.java)
            startActivity(intent)
        }

        btnfgt.setOnClickListener{
            val intent = Intent(this, Screen5::class.java)
            startActivity(intent)
        }
    }
}
