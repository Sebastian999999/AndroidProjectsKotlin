package com.HammadIrfan.i191994

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class Screen04 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen04)

        var btn = findViewById<Button>(R.id.verifybutton)
        var backbtn = findViewById<ImageView>(R.id.backbutton)
        btn.setOnClickListener{
            Toast.makeText(this,"Verifying", Toast.LENGTH_LONG).show()
            startActivity(Intent(this,Screen04::class.java))
        }

        backbtn.setOnClickListener{
            backbtn.setImageDrawable(getDrawable(R.drawable.backbuttonclickaction))
            val intent = Intent(this, Screen2::class.java)
            startActivity(intent)
        }


    }
}