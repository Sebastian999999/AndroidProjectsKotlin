package com.HammadIrfan.i191994

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.SystemClock.sleep
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class Screen5 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen5)

        var email = findViewById<Button>(R.id.sendbutton)
        var btnback= findViewById<ImageView>(R.id.backbutton)
        var lgntxt = findViewById<TextView>(R.id.text3)
        email.setOnClickListener{
            Toast.makeText(this,"Email sent", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, Screen6::class.java))
        }

        lgntxt.setOnClickListener{
            val intent = Intent(this, Screen2::class.java)
            startActivity(intent)
        }

        btnback.setOnClickListener{
            btnback.setImageDrawable(getDrawable(R.drawable.backbuttonclickaction))
            sleep(1000)
            val intent = Intent(this, Screen2::class.java)
            startActivity(intent)
        }

    }
}